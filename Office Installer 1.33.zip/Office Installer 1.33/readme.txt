﻿								Office Installer
                 ——————————————————————————————————————————————————

 Программа предназначена для on-line и off-line установки Office 2016/2024 C2R. Так же имеется
возможность создать свой дистрибутив Office для последующей установки Office off-line.

                              Работа с программой:
                 ——————————————————————————————————————————————————
1. Удалите Office C2R с помощью кнопки "Удаление".
2. Удалите Office C2R с помощью "Force Remove Office" и  перезагрузите компьютер.
3. Установите Office, нажав кнопку "Install".


                     Как пользоваться вкладкой Download Office:
                 ——————————————————————————————————————————————————

 Данная вкладка служит для создания off-line дистрибутива той или иной версии и редакции Microsoft Office, для
последующей установки продукта без получения файлов из-вне.

1. Выберите необходимую версию офиса, разрядность и язык. Можно сделать полноценный х86-х64 дистрибутив.
Для этого в закладке разрядности выбрать пункт All (самый нижний). Нажмите кнопку Download и выберите папку
для файлов дистрибутива. Вы можете выбрать папку предыдущей сессии работы программы чтобы продолжит создание
дистрибутива, иначе будет начата новая сессия.
2. Если Вы желаете дополнить скачанный дистрибутив, нажмите кнопку Download и укажите ту же самую папку для загрузки.
3. После окончания загрузки всех необходимых разрядностей и языков можно создать ISO-образ офисного пакета.
Для этого нажмите кнопку Create ISO.
4. В итоге в выбранной папке Вы увидите готовый к применению off-line установщик Microsoft Office
выбранной Вами редакции.

 
	                       Дополнительные параметры 
                           запуска программы  (ключи):
                 ——————————————————————————————————————————————————
/install	- Запустить программу в скрытом режиме и выполнить установку Office с ранее настроенными параметрами.
	Рядом с программой должен находиться файлик Office Installer.ini с настроенными параметрами. Установка
	может выполняться как в on-line режиме, так и в режиме off-line (рядом с программой должна лежать папка Office
	с ранее скачанным дистрибутивом)
	Параметры тихой установки задаются при первичной конфигурации в графической оболочке.
/ini:"название ини файла" - Использовать свой файл предварительных настроек. Можно использовать при установке
	с параметрами комстроки.



                           Дополнительные вопросы
                 ——————————————————————————————————————————————————
	После удаления офиса штатными средствами, в системе остаются его лицензии и ключи. Если у вас ранее был установлен, например,
Office 2016, вы его удалили и установили Office 2024 - может так получиться, что в свойствах офисного приложения вы увидите,
не Office 2024, а Office 2016. Чтобы такого не произошло, желательно после удаления старого офиса в разделе программы
"Лицензии Office" посмотреть оставшиеся в системе лицензии и удалить не нужные. Если удалять лицензии с включенным переключателем
"Удалить ключи" - из системы удалятся ключи с которыми был установлен старый офис.




								Office Installer
                 ——————————————————————————————————————————————————

 The program is designed for on-line and offline installation of Office 2016/2024 C2R. There is also
the ability to create your own Office distribution for subsequent installation of Office off-line.

                              Working with the program:
                 ——————————————————————————————————————————————————
1. Uninstall Office C2R using the Uninstall button.
2. Remove Office C2R using "Force Remove Office" and restart your computer.
3. Install Office by clicking the "Install" button.


						How to use the Download Office tab:
                 ——————————————————————————————————————————————————

 This tab is used to create an off-line distribution of a particular version and edition of Microsoft Office, for
subsequent installation of the product without receiving files from outside.

1. Select the required Office version, bit depth and language. You can make a full-fledged x86-x64 distribution.
	To do this, in the bit depth tab, select the All item (lowest). Click the Download button and select a folder
	for distribution files. You can select the folder of the previous session of the program to continue creating
	distribution, otherwise a new session will be started.
2. If you want to supplement the downloaded distribution, click the Download button and specify the same download folder.
3. After downloading all the necessary bits and languages, you can create an ISO image of the office suite.
	To do this, click the Create ISO button.
4. As a result, in the selected folder you will see a ready-to-use off-line Microsoft Office installer
	edition of your choice.
	
	
				Extra options, program launch (keys):
                 ——————————————————————————————————————————————————
/install - Run the program in stealth mode and install Office with the previously configured settings.
	Next to the program there should be an Office Installer.ini file with configured parameters. Installation
	can be executed both in on-line mode and in off-line mode (the Office folder should be located next to the program
	with a previously downloaded distribution)
/ini:"ini file name" - Use your own presettings file. Can be used during installation
	with command line parameters.


                           Additional questions
                 ——————————————————————————————————————————————————
After deleting an office using standard means, its licenses and keys remain in the system. If you previously had, for example,
Office 2016, you uninstalled it and installed Office 2024 - it may happen that in the properties of the office application you will see
not Office 2024, but Office 2016. To prevent this from happening, it is advisable to delete the old office in the program section
"Office Licenses" view the remaining licenses in the system and delete those that are not needed. If you delete licenses with the switch enabled
“Delete keys” - the keys with which the old office was installed will be deleted from the system.	
	



Изменения в версиях :
—————————————————————
v1.3.3
- В программе изменена ссылка для загрузки дистрибутива.

v1.3.2
- В программе используется другая версия aria2.

v1.3.1
- Добавлена для установки редакция Mondo 2016 Retail.

v1.3.0
- Расположение файла ospp.vbs изменилось, программа не могла его найти.

v1.2.9
- Когда Office не установлен или не найден ospp.vbs, используется встроенный в программу ospp.vbs.

v1.2.8
- В окнах установки и изменения канала обновлений отображается установленная версия Office.

v1.2.7
- В настройках добавлен переключатель "Не устанавливать GVLK ключи". Это полезно, когда вы устанавливаете
  Office поверх уже установленного и активированного MAK ключом.

v1.2.6
- В управлении лицензиями добавлены новые лицензии.

v1.2.5
- Исправлена установка проверки орфографии.

v1.2.3
- Исправление ошибок, мелкие изменения в интерфейсе и логике программы.

v1.2.2
- Из программы удален ODT. При включенном переключателе "Создавать ISO с альтернативным установщиком",
  создается командный файл для запуска установки.
- Добавлена возможность подключать распакованные образы дистрибутивов Office для установки с них.
- При установке Office в скрытом режиме сообщение в конце установки подавляется.

v1.2.1
- Меню по правой кнопке мышки на вкладке управления лицензиями Office. Работает сортировка.
- Возможность установить свой ключ.
- Добавлен переключатель "Создавать ISO с ODT". Чтобы антивирусы не сильно ругались.

v1.1.9
- Дополнен список файлов при скачивании дистрибутива офиса.

v1.1.8
- При работе с ISO или с рядом лежащим дистрибутивом, добавлен переключатель "Разблокировать список каналов"

v1.1.7
- Добавлена поддержка установки Office 2024 ProPlus Release.

v1.1.6
- Исправлено возможное "падение" программы в конце создания ISO.

v1.1.5
- Исправлено отображение версии установленного офиса.

v1.1.4
- Изменения в интерфейсе программы.
- Улучшения и оптимизации в коде программы.

v1.1.2
- При запуске на Windows 7 выбирается редакция ProPlus 2016 Volume
- Из списка компонентов убран Teams, оставлен только в O363 ProPlus Retail.
- Мелкие исправления.

v1.1.1
- При загрузке дистрибутива выбирается рабочее зеркало.


v1.1.0
- Исправление ошибок.
- Переделано окно загрузки дистрибутива.
- Изменен компилятор для x64 версий.

v1.0.9
- Исправление ошибок.

v1.0.8
- Исправление ошибок.
- Доработка интерфейса.

v1.0.7
- Новые редакции Office для установки.
- Переключатель в настройках "Скрыть RETAIL редакции Office"
- Новые переключатели комстроки.

v1.0.5
- Исправлена работа кнопки Создать ISO.
- Доработка Нового интерфейса.
v1.0.3
- Добавлена установка Office из командной строки.
